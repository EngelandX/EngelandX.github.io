<?php

return [
	'app.name' => 'Portfolio Site',
	'session.name' => 'portfolio',
];
